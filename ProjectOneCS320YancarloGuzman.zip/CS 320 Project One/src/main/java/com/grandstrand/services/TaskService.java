package main.java.com.grandstrand.services;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public boolean addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            return false;
        }
        tasks.put(task.getTaskId(), task);
        return true;
    }

    public boolean deleteTask(String taskId) {
        return tasks.remove(taskId) != null;
    }

    public boolean updateTask(String taskId, String name, String description) {
        Task task = tasks.get(taskId);
        if (task == null) {
            return false;
        }

        if (name != null && name.length() <= 20) {
            task.setName(name);
        }
        if (description != null && description.length() <= 50) {
            task.setDescription(description);
        }
        return true;
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
