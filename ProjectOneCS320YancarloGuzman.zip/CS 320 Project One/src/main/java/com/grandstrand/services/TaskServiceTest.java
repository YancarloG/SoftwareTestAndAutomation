package main.java.com.grandstrand.services;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("task1", "Task Name", "Task Description");
        assertTrue(taskService.addTask(task));
        assertFalse(taskService.addTask(task)); // Duplicate
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("task1", "Task Name", "Task Description");
        taskService.addTask(task);
        assertTrue(taskService.deleteTask("task1"));
        assertFalse(taskService.deleteTask("task2"));
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task("task1", "Task Name", "Task Description");
        taskService.addTask(task);

        assertTrue(taskService.updateTask("task1", "Updated Task Name", "Updated Task Description"));
        Task updatedTask = taskService.getTask("task1");
        assertEquals("Updated Task Name", updatedTask.getName());
        assertEquals("Updated Task Description", updatedTask.getDescription());

        assertFalse(taskService.updateTask("task2", "Updated Task Name", "Updated Task Description")); // Non-existent task
    }
}

