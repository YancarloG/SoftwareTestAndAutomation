package main.java.com.grandstrand.services;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentTest {
    @Test
    public void testAppointmentCreation() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // Future date
        Appointment appointment = new Appointment("appt1", futureDate, "Appointment Description");
        assertNotNull(appointment);
        assertEquals("appt1", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Appointment Description", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentCreation() {
        Date pastDate = new Date(System.currentTimeMillis() - 100000); // Past date

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, new Date(), "Appointment Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("appt12345678", new Date(), "Appointment Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("appt1", pastDate, "Appointment Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("appt1", new Date(), "Description exceeding fifty characters in length is not allowed.");
        });
    }
}

