package main.java.com.grandstrand.services;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {
    @Test
    public void testTaskCreation() {
        Task task = new Task("task1", "Task Name", "Task Description");
        assertNotNull(task);
        assertEquals("task1", task.getTaskId());
        assertEquals("Task Name", task.getName());
        assertEquals("Task Description", task.getDescription());
    }

    @Test
    public void testInvalidTaskCreation() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Task Name", "Task Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("task12345678", "Task Name", "Task Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("task1", null, "Task Description");
        });
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("task1", "Task Name", "Description exceeding fifty characters in length is not allowed.");
        });
    }
}
