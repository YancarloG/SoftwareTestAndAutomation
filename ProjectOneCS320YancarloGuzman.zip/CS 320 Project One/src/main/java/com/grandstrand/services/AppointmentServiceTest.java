package main.java.com.grandstrand.services;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentServiceTest {
    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // Future date
        Appointment appointment = new Appointment("appt1", futureDate, "Appointment Description");
        assertTrue(appointmentService.addAppointment(appointment));
        assertFalse(appointmentService.addAppointment(appointment)); // Duplicate
    }

    @Test
    public void testDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 100000); // Future date
        Appointment appointment = new Appointment("appt1", futureDate, "Appointment Description");
        appointmentService.addAppointment(appointment);
        assertTrue(appointmentService.deleteAppointment("appt1"));
        assertFalse(appointmentService.deleteAppointment("appt2"));
    }
}

