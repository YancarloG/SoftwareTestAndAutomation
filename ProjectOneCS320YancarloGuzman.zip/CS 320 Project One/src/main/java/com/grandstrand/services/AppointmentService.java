package main.java.com.grandstrand.services;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

    public boolean addAppointment(Appointment appointment) {
        if (appointments.containsKey(appointment.getAppointmentId())) {
            return false;
        }
        appointments.put(appointment.getAppointmentId(), appointment);
        return true;
    }

    public boolean deleteAppointment(String appointmentId) {
        return appointments.remove(appointmentId) != null;
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
