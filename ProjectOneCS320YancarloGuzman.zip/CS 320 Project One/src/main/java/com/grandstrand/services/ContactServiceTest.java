package main.java.com.grandstrand.services;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("12345", "Mickey", "Mouse", "1234567890", "123 Main St");
        assertTrue(contactService.addContact(contact));
        assertFalse(contactService.addContact(contact)); // Duplicate
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("12345", "Mickey", "Mouse", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertTrue(contactService.deleteContact("12345"));
        assertFalse(contactService.deleteContact("54321"));
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("12345", "Mickey", "Mouse", "1234567890", "123 Main St");
        contactService.addContact(contact);

        assertTrue(contactService.updateContact("12345", "Minnie", "Mouse", "0987654321", "456 Elm St"));
        Contact updatedContact = contactService.getContact("12345");
        assertEquals("Minnie", updatedContact.getFirstName());
        assertEquals("Mouse", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Elm St", updatedContact.getAddress());

        assertFalse(contactService.updateContact("54321", "Minnie", "Mouse", "0987654321", "456 Elm St")); // Non-existent contact
    }
}
